import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const ShonudApp());
}

/// -------------------- رنگ‌ها (آبی / سفید / مشکی) --------------------
class C {
  static const background = Color(0xFF0A0E14);
  static const cardBg = Color(0xFF121820);
  static const cardBorder = Color(0xFF223040);
  static const blue = Color(0xFF4FC3F7);
  static const blueDim = Color(0xFF2F6E8C);
  static const white = Color(0xFFF5F7FA);
  static const grayText = Color(0xFFAEB8C4);
}

/// -------------------- مدل یک بلوکِ حدیث --------------------
class HadithBlock {
  final String? sectionTitle;
  final String? experiencerSummary;
  final String? narrator;
  final String? arabic;
  final String? farsi;
  final String? source;
  final String? note;
  const HadithBlock({
    this.sectionTitle,
    this.experiencerSummary,
    this.narrator,
    this.arabic,
    this.farsi,
    this.source,
    this.note,
  });
}

/// -------------------- حدیث‌های فصل یک --------------------
final Map<int, List<HadithBlock>> kSeason1Hadiths = {
  1: [
    HadithBlock(
      sectionTitle: 'دیدار و ارتباط روح با اموات و اجداد',
      experiencerSummary:
          'آقای صادق هنگام حرکت به سوی نور، صدای مادربزرگ و پدربزرگِ درگذشته‌اش را می‌شنود و حضور اجدادش را احساس می‌کند؛ آنها درباره‌ی آمدن او با یکدیگر صحبت می‌کردند و منتظر بودند بدانند چرا هنوز به آنها نرسیده است.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّ الْأَرْوَاحَ فِی صِفَةِ الْأَجْسَادِ فِی شَجَرَةٍ فِی الْجَنَّةِ، تَعَارَفُ وَتَسَاءَلُ، فَإِذَا قَدِمَتِ الرُّوحُ عَلَی الْأَرْوَاحِ قَالَتْ: دَعُوهَا فَإِنَّهَا قَدْ أَفْلَتَتْ مِنْ هَوْلٍ عَظِیمٍ، ثُمَّ یَسْأَلُونَهَا: مَا فَعَلَ فُلَانٌ وَمَا فَعَلَ فُلَانٌ؟',
      farsi:
          'همانا ارواح در جایگاهی در بهشت، یکدیگر را می‌شناسند و از حال هم پرس‌وجو می‌کنند. هنگامی که روحی نزد ارواح می‌آید، می‌گویند: او را رها کنید؛ زیرا از هول و هراس بزرگی رهایی یافته است. سپس از او می‌پرسند: فلانی چه کرد و فلانی چه کرد؟',
      source: 'الکافی، شیخ کلینی، ج ۳، ص ۲۴۴',
    ),
    HadithBlock(
      sectionTitle: 'مواجهه با ملک‌الموت و لحظه‌ی قبض روح',
      experiencerSummary:
          'او موجودی بسیار نورانی و باهیبت را می‌بیند که به او می‌فهماند برای گرفتن جانش آمده است؛ او را ملک‌الموت می‌داند و در برابرش کاملاً تسلیم می‌شود.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّهُ إِذَا أَتَاهُ مَلَکُ الْمَوْتِ لِقَبْضِ رُوحِهِ جَزِعَ عِنْدَ ذَلِکَ، فَیَقُولُ لَهُ مَلَکُ الْمَوْتِ: یَا وَلِیَّ اللَّهِ، لَا تَجْزَعْ...',
      farsi:
          'هنگامی که ملک‌الموت برای گرفتن روح مؤمن نزد او می‌آید، او در آن لحظه بی‌تاب می‌شود. پس ملک‌الموت به او می‌گوید: ای ولیّ خدا، بی‌تابی نکن...',
      source: 'الکافی، شیخ کلینی، ج ۳، ص ۱۲۷',
    ),
  ],
  2: [
    HadithBlock(
      sectionTitle: 'ارزش پنهان اعمال کوچک و نیت خالص',
      experiencerSummary:
          'تجربه‌گر در مرور اعمالش متوجه می‌شود بسیاری از کارهایی که اصلاً حسابشان نمی‌کرد، ارزش زیادی داشته‌اند؛ مانند کمک به مادر، جمع‌کردن رختخوابش و خریدن نان برایش. در مقابل، برخی کارهای بزرگش به‌دلیل نیت‌های غیرخالص، ارزشی برایش نداشتند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّمَا یَخْتَبِرُ اللَّهُ عَزَّ وَجَلَّ عِبَادَهُ لَا بِکَثْرَةِ الْعَمَلِ، وَلَکِنْ بِأَصْوَبِهِ، وَإِنَّمَا یُصَابُ بِالْإِخْلَاصِ، وَالنِّیَّةُ أَفْضَلُ مِنَ الْعَمَلِ.',
      farsi:
          'خداوند بندگانش را به زیادیِ عمل نمی‌آزماید، بلکه به درست و شایسته بودن عمل می‌آزماید؛ و عمل با اخلاص ارزش می‌یابد، و نیت از خودِ عمل برتر است.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الإخلاص، حدیث ۴',
      note: '(متن عربی این حدیث در منبع اصلی دارای ناهماهنگی بود و در این‌جا برای رفع تناقض، ویرایش جزئی شده است.)',
    ),
    HadithBlock(
      sectionTitle: 'نجات جان انسان و بیرون‌آوردن او از گمراهی',
      experiencerSummary:
          'آقای صادق در مرور اعمالش دید که نجاتِ جانِ چند نفر، از جمله جلوگیری از خودکشی یک نوجوان و نجات جوانی از کشته‌شدن، از اعمال ارزشمند او محسوب شده است.',
      narrator: 'امام محمد باقر علیه‌السلام',
      arabic: 'وَمَنْ أَحْیَاهَا فَکَأَنَّمَا أَحْیَا النَّاسَ جَمِیعًا...',
      farsi: 'هر کس انسانی را زنده کند، گویی همه‌ی مردم را زنده کرده است... (ادامه دارد)',
      source: 'الکافی، شیخ کلینی، ج ۲، باب «فی إحیاء المؤمن»',
    ),
  ],
  3: [
    HadithBlock(
      sectionTitle: 'خروج روح از بدن و بازگشت آن',
      experiencerSummary:
          'او خود را در گوشه‌ی سقف بیمارستان می‌بیند، بدن خودش را از بالا مشاهده می‌کند و نمی‌تواند به بدن بازگردد؛ سپس در ادامه دوباره وارد بدن می‌شود.',
      narrator: 'امام علی علیه‌السلام',
      arabic:
          'فَإِنَّ رُوحَ الْمُؤْمِنِ تُرْفَعُ إِلَی اللَّهِ تَبَارَکَ وَتَعَالَی فَیَقْبَلُهَا وَیُبَارِکُ عَلَیْهَا، فَإِنْ کَانَ أَجَلُهَا قَدْ حَضَرَ جَعَلَهَا فِی کُنُوزِ رَحْمَتِهِ، وَإِنْ لَمْ یَکُنْ أَجَلُهَا قَدْ حَضَرَ بَعَثَ بِهَا مَعَ أُمَنَائِهِ مِنْ مَلَائِکَتِهِ فَیَرُدُّونَهَا فِی جَسَدِهَا.',
      farsi:
          'روح مؤمن به‌سوی خدای تبارک و تعالی بالا برده می‌شود و خداوند آن را می‌پذیرد و بر آن برکت می‌دهد. اگر زمان مرگش فرا رسیده باشد، آن را در گنجینه‌های رحمت خود قرار می‌دهد؛ و اگر هنوز زمان مرگش نرسیده باشد، آن را به‌وسیله‌ی فرشتگان امین خود بازمی‌فرستد و آنان روح را به بدنش بازمی‌گردانند.',
      source: 'الخصال، شیخ صدوق',
    ),
  ],
  4: [
    HadithBlock(
      sectionTitle: 'مشاهده‌ی کربلا و نورانیت حرم امام حسین علیه‌السلام',
      experiencerSummary:
          'تجربه‌گر از مشاهده‌ی جهانی متفاوت سخن می‌گوید و کربلا و حرم امام حسین علیه‌السلام را به‌صورت جایگاهی بسیار نورانی و متفاوت از دیگر مکان‌ها مشاهده می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic: 'مَوْضِعُ قَبْرِ الْحُسَیْنِ عَلَیْهِ السَّلَامُ مُنْذُ یَوْمِ دُفِنَ فِیهِ رَوْضَةٌ مِنْ رِیَاضِ الْجَنَّةِ.',
      farsi: 'جایگاه قبر حسین علیه‌السلام از همان روزی که در آن دفن شد، باغی از باغ‌های بهشت است.',
      source: 'من لا یحضره الفقیه، شیخ صدوق، ج ۲، ص ۲۲۹',
    ),
  ],
  5: [
    HadithBlock(
      sectionTitle: 'حمله‌ی شیاطین و پناه‌بردن به ذکر خدا',
      experiencerSummary:
          'آقای صادق در حالت نزدیک به مرگ، موجودات وحشتناکی را می‌بیند که به‌شدت به او حمله می‌کنند و حتی زبانش از ترس قفل می‌شود. با توسل به حضرت زهرا و اهل‌بیت و گفتن ذکرهایی مانند «بسم‌الله الرحمن الرحیم» و «لا حول ولا قوة إلا بالله العلی العظیم»، می‌بیند که آنها از او فاصله می‌گیرند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ أَحَدٍ یَحْضُرُهُ الْمَوْتُ إِلَّا وَکَّلَ بِهِ إِبْلِیسُ مِنْ شَیَاطِینِهِ مَنْ یَأْمُرُهُ بِالْکُفْرِ وَیُشَکِّکُهُ فِی دِینِهِ حَتَّی تَخْرُجَ نَفْسُهُ، فَمَنْ کَانَ مُؤْمِنًا لَمْ یَقْدِرْ عَلَیْهِ...',
      farsi:
          'هیچ‌کس نیست که مرگش فرا برسد، مگر اینکه ابلیس یکی از شیاطینش را بر او می‌گمارد تا او را به کفر بکشاند و در دینش دچار تردید کند تا جانش از بدن بیرون رود؛ اما اگر مؤمن باشد، شیطان نمی‌تواند بر او غلبه کند...',
      source: 'الکافی، شیخ کلینی، ج ۳، باب «ما یعاین المؤمن والکافر عند الموت»',
    ),
  ],
  6: [
    HadithBlock(
      sectionTitle: 'تلاش شیطان برای منحرف‌کردن انسان در آخرین لحظات عمر',
      experiencerSummary:
          'آقای صادق می‌گوید شیاطین در هنگام مرگ تلاش می‌کنند انسان متوجه خدا نشود و با ایجاد سرگرمی و بهانه، او را از توسل و توجه به خدا دور کنند. او این مسئله را هنگام مشاهده‌ی یک پیرمرد در حال مرگ نیز شرح می‌دهد.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ أَحَدٍ یَحْضُرُهُ الْمَوْتُ إِلَّا وَکَّلَ بِهِ إِبْلِیسُ مِنْ شَیَاطِینِهِ مَنْ یَأْمُرُهُ بِالْکُفْرِ وَیُشَکِّکُهُ فِی دِینِهِ حَتَّی تَخْرُجَ نَفْسُهُ، فَمَنْ کَانَ مُؤْمِنًا لَمْ یَقْدِرْ عَلَیْهِ.',
      farsi:
          'وقتی مرگ انسان فرا می‌رسد، ابلیس یکی از شیاطینش را بر او می‌گمارد تا او را به کفر دعوت کند و در دینش به تردید بیندازد تا جانش از بدن بیرون برود؛ اما اگر مؤمن باشد، شیطان نمی‌تواند بر او چیره شود.',
      source: 'الکافی، شیخ کلینی، ج ۳، باب «ما یعاین المؤمن والکافر عند الموت»',
    ),
  ],
  7: [
    HadithBlock(
      sectionTitle: 'وسوسه‌ی شیطان و نجوا در گوش انسان',
      experiencerSummary:
          'آقای صادق شیطان را موجودی توصیف می‌کند که در کنار انسان قرار می‌گیرد و با وسوسه و توجیه، انسان را از توجه به خدا و انجام کار درست دور می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ قَلْبٍ إِلَّا وَلَهُ أُذُنَانِ، عَلَی إِحْدَاهُمَا مَلَکٌ مُرْشِدٌ، وَعَلَی الْأُخْرَی شَیْطَانٌ مُفْتِنٌ، هَذَا یَأْمُرُهُ وَهَذَا یَزْجُرُهُ، الشَّیْطَانُ یَأْمُرُهُ بِالْمَعَاصِی، وَالْمَلَکُ یَزْجُرُهُ عَنْهَا.',
      farsi:
          'هر قلبی دو گوش دارد؛ بر یکی فرشته‌ای راهنماست و بر دیگری شیطانی وسوسه‌گر. یکی فرمان می‌دهد و دیگری بازمی‌دارد؛ شیطان انسان را به گناه دعوت می‌کند و فرشته او را از آن بازمی‌دارد.',
      source: 'الکافی، شیخ کلینی، ج ۲',
    ),
  ],
  9: [
    HadithBlock(
      sectionTitle: 'خشم و نقش شیطان در تحریک انسان',
      experiencerSummary:
          'در مشاهداتش، ارتباط میان خشم شدید انسان و حضور شیطان را توصیف می‌کند و می‌گوید شیطان می‌تواند از خشم انسان برای تحریک رفتار و خارج‌کردن او از کنترل استفاده کند.',
      narrator: 'امام محمد باقر علیه‌السلام',
      arabic:
          'إِنَّ هَذَا الْغَضَبَ جَمْرَةٌ مِنَ الشَّیْطَانِ تُوقَدُ فِی قَلْبِ ابْنِ آدَمَ، وَإِنَّ أَحَدَکُمْ إِذَا غَضِبَ احْمَرَّتْ عَیْنَاهُ، وَانْتَفَخَتْ أَوْدَاجُهُ، وَدَخَلَ الشَّیْطَانُ فِیهِ...',
      farsi:
          'این خشم، شراره‌ای از شیطان است که در قلب فرزند آدم افروخته می‌شود. هنگامی که یکی از شما خشمگین می‌شود، چشمانش سرخ و رگ‌هایش متورم می‌شود و شیطان در او وارد می‌شود...',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الغضب',
    ),
  ],
  10: [
    HadithBlock(
      sectionTitle: 'اثر اعمال انسان بر دیگران و حق‌الناس',
      experiencerSummary:
          'آقای صادق در مرور اعمالش می‌بیند بعضی رفتارها و زخم‌زبان‌هایی که در دنیا کم‌اهمیت می‌دانسته، آثار واقعی داشته‌اند و انسان نسبت به پیامد رفتار خود در برابر دیگران مسئول است.',
      narrator: 'امام صادق علیه‌السلام',
      arabic: 'مَنْ ظَلَمَ مَظْلِمَةً أُخِذَ بِهَا فِی نَفْسِهِ أَوْ فِی مَالِهِ أَوْ فِی وُلْدِهِ.',
      farsi: 'هر کس به دیگری ستمی کند، به سبب آن ستم مؤاخذه خواهد شد؛ در جانش یا مالش یا فرزندش.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الظلم',
    ),
  ],
  11: [
    HadithBlock(
      sectionTitle: 'باقی‌ماندن آثار عمل انسان پس از مرگ',
      experiencerSummary:
          'آقای صادق توضیح می‌دهد برخی رفتارهای انسان فقط به لحظه‌ی انجامشان محدود نمی‌شوند و آثار خیر آنها می‌تواند پس از مرگ نیز ادامه پیدا کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'لَیْسَ یَتْبَعُ الرَّجُلَ بَعْدَ مَوْتِهِ مِنَ الْأَجْرِ إِلَّا ثَلَاثُ خِصَالٍ: صَدَقَةٌ أَجْرَاهَا فِی حَیَاتِهِ فَهِیَ تَجْرِی بَعْدَ مَوْتِهِ، وَسُنَّةُ هُدًی سَنَّهَا فَهِیَ یُعْمَلُ بِهَا بَعْدَ مَوْتِهِ، أَوْ وَلَدٌ صَالِحٌ یَدْعُو لَهُ.',
      farsi:
          'پس از مرگ انسان، پاداش سه چیز همچنان به او می‌رسد: صدقه‌ای که در زندگی انجام داده و پس از مرگش ادامه دارد؛ راه و روش هدایتی که پایه گذاشته و بعد از مرگش به آن عمل می‌شود؛ یا فرزند صالحی که برای او دعا می‌کند.',
      source: 'الکافی، شیخ کلینی، ج ۷، باب «ما یلحق المیت بعد موته»',
    ),
  ],
  12: [
    HadithBlock(
      sectionTitle: 'اثر گناه و پاک‌شدن آن با توبه',
      experiencerSummary:
          'او گناه را دارای اثری واقعی می‌داند که می‌تواند بر انسان باقی بماند و توبه را سبب پاک‌شدن این آثار معرفی می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِذَا أَذْنَبَ الرَّجُلُ خَرَجَ فِی قَلْبِهِ نُکْتَةٌ سَوْدَاءُ، فَإِنْ تَابَ انْمَحَتْ، وَإِنْ زَادَ زَادَتْ حَتَّی تَغْلِبَ عَلَی قَلْبِهِ فَلَا یُفْلِحُ بَعْدَهَا أَبَدًا.',
      farsi:
          'هرگاه انسان گناهی مرتکب شود، نقطه‌ای سیاه در قلبش پدید می‌آید؛ اگر توبه کند، آن نقطه پاک می‌شود؛ و اگر بر گناه بیفزاید، آن نقطه بیشتر می‌شود تا جایی که بر قلبش غلبه کند.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الذنوب',
    ),
  ],
  13: [
    HadithBlock(
      sectionTitle: 'حضور سپاه فرشتگان در یاری قائم آل‌محمد علیهم‌السلام',
      experiencerSummary:
          'آقای صادق در مشاهدات خود سپاهی عظیم از فرشتگان را می‌بیند که مسلح و آماده‌اند و درباره‌ی مأموریت آنها برای یاری جبهه‌ی حق و حضرت صاحب‌الزمان عجل‌الله‌تعالی‌فرجه صحبت می‌شود.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'فَیَنْحَطُّ عَلَیْهِ ثَلَاثَةَ عَشَرَ أَلْفَ مَلَکٍ وَثَلَاثَ مِائَةٍ وَثَلَاثَةَ عَشَرَ مَلَکًا. قُلْتُ: کُلُّ هَؤُلَاءِ الْمَلَائِکَةِ؟ قَالَ: نَعَمْ، الَّذِینَ کَانُوا مَعَ نُوحٍ فِی السَّفِینَةِ، وَالَّذِینَ کَانُوا مَعَ إِبْرَاهِیمَ حِینَ أُلْقِیَ فِی النَّارِ، وَالَّذِینَ کَانُوا مَعَ مُوسَی حِینَ فَلَقَ الْبَحْرَ لِبَنِی إِسْرَائِیلَ، وَالَّذِینَ کَانُوا مَعَ عِیسَی حِینَ رَفَعَهُ اللَّهُ إِلَیْهِ، وَأَرْبَعَةُ آلَافِ مَلَکٍ مَعَ النَّبِیِّ صَلَّی اللَّهُ عَلَیْهِ وَآلِهِ مُسَوَّمِینَ، وَأَلْفٌ مُرْدِفِینَ، وَثَلَاثَةُ مِائَةٍ وَثَلَاثَةَ عَشَرَ مَلَکًا بَدْرِیِّینَ، وَأَرْبَعَةُ آلَافِ مَلَکٍ هَبَطُوا یُرِیدُونَ الْقِتَالَ مَعَ الْحُسَیْنِ عَلَیْهِ السَّلَامُ.',
      farsi:
          'سیزده هزار و سیصد و سیزده فرشته بر او (حضرت حجت) فرود می‌آیند. پرسیدم: همه‌ی این فرشتگان؟ فرمود: آری؛ همان فرشتگانی که با نوح در کشتی بودند، با ابراهیم هنگامی که او را در آتش افکندند، با موسی هنگامی که دریا را برای بنی‌اسرائیل شکافت، و با عیسی هنگامی که خدا او را به‌سوی خود بالا برد. هم‌چنین چهار هزار فرشته که با پیامبر صلی‌الله‌علیه‌وآله بودند، و فرشتگان جنگ بدر، و چهار هزار فرشته که برای جنگیدن در کنار حسین علیه‌السلام فرود آمدند.',
      source: 'کمال‌الدین و تمام النعمة، شیخ صدوق؛ بحارالانوار، علامه مجلسی، ج ۵۲',
      note: '(اصل روایت معتبر است؛ شماره‌ها و منبع دقیق در نسخه‌های مختلف اندکی متفاوت نقل شده و این‌جا یکدست شده است.)',
    ),
  ],
};

/// حدیث فصل دوم (فقط قسمت اول موجود است)
final Map<int, List<HadithBlock>> kSeason2Hadiths = {
  1: [
    HadithBlock(
      sectionTitle: 'ادراک روحانی و لذت‌های گسترده‌تر در عالم دیگر',
      experiencerSummary:
          'آقای صادق توضیح می‌دهد که در عالم روحانی، ادراک انسان دیگر محدود به حواس جسمانی نیست؛ روح می‌تواند لذت‌ها و زیبایی‌هایی را درک کند که در دنیا قابل مقایسه با آنها نیست و این لذت‌ها برایش محدود و تکراری نمی‌شوند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّ اللَّهَ خَلَقَ بِیَدِهِ جَنَّةً لَمْ یَرَهَا عَیْنٌ، وَلَمْ یَطَّلِعْ عَلَیْهَا مَخْلُوقٌ، یَفْتَحُهَا الرَّبُّ تَبَارَکَ وَتَعَالَی کُلَّ صَبَاحٍ فَیَقُولُ: ازْدَادِی طِیبًا، ازْدَادِی رِیحًا، فَتَقُولُ: قَدْ أَفْلَحَ الْمُؤْمِنُونَ.',
      farsi:
          'خداوند به‌دست قدرت خود بهشتی آفریده که هیچ چشمی آن را ندیده و هیچ آفریده‌ای از آن آگاهی نیافته است. پروردگار هر صبح آن را می‌گشاید و به آن می‌فرماید: بر زیبایی و عطر و طراوتت بیفزا. و آن بهشت می‌گوید: مؤمنان رستگار شدند.',
      source: 'کتاب الزهد، شیخ حسین بن سعید اهوازی، باب «صفات الجنة والنار»، حدیث ۱۱',
    ),
  ],
};

/// -------------------- اپ --------------------
class ShonudApp extends StatelessWidget {
  const ShonudApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مستند صوتی شنود',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const HomeScreen(),
    );
  }
}

/// -------------------- شناسه‌ی یک قسمتِ درحال پخش --------------------
class PlayingTrack {
  final int season;
  final int part;
  const PlayingTrack(this.season, this.part);
  @override
  bool operator ==(Object other) => other is PlayingTrack && other.season == season && other.part == part;
  @override
  int get hashCode => Object.hash(season, part);
}

/// -------------------- صفحه اصلی --------------------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AudioPlayer _player = AudioPlayer();
  PlayingTrack? _current;
  bool _isPlaying = false;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _vibrate() async {
    try {
      if (await Vibration.hasVibrator()) {
        Vibration.vibrate(duration: 18, amplitude: 120);
        return;
      }
    } catch (_) {}
    HapticFeedback.selectionClick();
  }

  String _assetFor(int season, int part) {
    if (season == 1) return 'audio/mostanad_soti_shonud_part$part.mp3';
    return 'audio/mostanad_soti_shonud_s2_part$part.mp3';
  }

  Future<void> _playTrack(int season, int part) async {
    _vibrate();
    if (_current == PlayingTrack(season, part)) {
      if (_isPlaying) {
        await _player.pause();
        setState(() => _isPlaying = false);
      } else {
        await _player.resume();
        setState(() => _isPlaying = true);
      }
      return;
    }
    await _player.stop();
    await _player.play(AssetSource(_assetFor(season, part)));
    setState(() {
      _current = PlayingTrack(season, part);
      _isPlaying = true;
    });
  }

  Future<void> _stopTrack() async {
    _vibrate();
    await _player.stop();
    setState(() {
      _isPlaying = false;
      _current = null;
    });
  }

  Future<void> _seekBy(int seconds) async {
    _vibrate();
    final pos = await _player.getCurrentPosition() ?? Duration.zero;
    var target = pos + Duration(seconds: seconds);
    if (target < Duration.zero) target = Duration.zero;
    await _player.seek(target);
  }

  void _openHadithSheet(int season, int part) {
    _vibrate();
    final list = season == 1 ? kSeason1Hadiths[part] : kSeason2Hadiths[part];
    showModalBottomSheet(
      context: context,
      backgroundColor: C.cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          minChildSize: 0.4,
          maxChildSize: 0.92,
          expand: false,
          builder: (context, scrollController) {
            return Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: const BoxDecoration(
                    border: Border(bottom: BorderSide(color: C.cardBorder)),
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(color: C.blue.withOpacity(0.4), borderRadius: BorderRadius.circular(4)),
                      ),
                      const Text('حدیث‌های مرتبط', style: TextStyle(color: C.blue, fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                ),
                Expanded(
                  child: (list == null || list.isEmpty)
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(24),
                            child: Text('', style: TextStyle(color: C.grayText)),
                          ),
                        )
                      : ListView.builder(
                          controller: scrollController,
                          padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
                          itemCount: list.length,
                          itemBuilder: (context, i) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _buildHadithBlock(list[i]),
                                if (i != list.length - 1) _buildDivider(),
                              ],
                            );
                          },
                        ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, color: C.cardBorder)),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Text('\u262B', style: TextStyle(fontSize: 18, color: C.blue)),
          ),
          Expanded(child: Container(height: 1, color: C.cardBorder)),
        ],
      ),
    );
  }

  Widget _buildHadithBlock(HadithBlock h) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (h.sectionTitle != null) ...[
          Row(
            children: [
              const Icon(Icons.brightness_1, size: 7, color: C.blue),
              const SizedBox(width: 8),
              Expanded(
                child: Text(h.sectionTitle!, style: const TextStyle(color: C.blue, fontWeight: FontWeight.bold, fontSize: 14.5)),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],
        if (h.experiencerSummary != null) ...[
          const Text('خلاصه‌ی حرف‌های تجربه‌گر:', style: TextStyle(color: C.grayText, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(h.experiencerSummary!, textAlign: TextAlign.justify, style: const TextStyle(color: C.grayText, fontSize: 12.5, height: 1.8, fontStyle: FontStyle.italic)),
          const SizedBox(height: 14),
        ],
        if (h.arabic != null) ...[
          if (h.narrator != null) ...[
            Text(h.narrator!, style: const TextStyle(color: C.white, fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 8),
          ],
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: C.background,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: C.blueDim),
            ),
            child: Text(h.arabic!, textAlign: TextAlign.center, style: const TextStyle(color: C.white, fontSize: 15.5, height: 1.9)),
          ),
          const SizedBox(height: 10),
        ],
        if (h.farsi != null) ...[
          const Text('ترجمه‌ی فارسی:', style: TextStyle(color: C.grayText, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(h.farsi!, textAlign: TextAlign.justify, style: const TextStyle(color: C.grayText, fontSize: 12.5, height: 1.85)),
        ],
        if (h.source != null) ...[
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: Text('منبع: ${h.source!}', style: const TextStyle(color: C.blueDim, fontSize: 11)),
          ),
        ],
        if (h.note != null) ...[
          const SizedBox(height: 6),
          Text(h.note!, textAlign: TextAlign.center, style: const TextStyle(color: C.blueDim, fontSize: 10.5, fontStyle: FontStyle.italic)),
        ],
      ],
    );
  }

  Widget _buildPartCard(int season, int part) {
    final isThis = _current == PlayingTrack(season, part);
    return AnimatedScale(
      duration: const Duration(milliseconds: 220),
      scale: isThis && _isPlaying ? 1.035 : 1.0,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: const EdgeInsets.only(bottom: 10),
        child: GestureDetector(
          onTap: () => _playTrack(season, part),
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                height: 60,
                decoration: BoxDecoration(
                  color: isThis ? C.blue.withOpacity(0.12) : C.cardBg,
                  border: Border.all(color: isThis ? C.blue : C.cardBorder),
                ),
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Icon(
                        isThis && _isPlaying ? Icons.graphic_eq : Icons.play_circle_outline,
                        color: isThis ? C.blue : C.grayText,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'قسمت ${_toFarsiDigits(part)}',
                        style: TextStyle(
                          color: isThis ? C.blue : C.white,
                          fontWeight: isThis ? FontWeight.bold : FontWeight.w600,
                          fontSize: 14.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 0,
                left: 0,
                child: GestureDetector(
                  onTap: () => _openHadithSheet(season, part),
                  child: Container(
                    width: 30,
                    height: 30,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: C.blue.withOpacity(0.12),
                      border: Border(right: BorderSide(color: C.cardBorder), bottom: BorderSide(color: C.cardBorder)),
                    ),
                    child: const Text('!', style: TextStyle(color: C.blue, fontWeight: FontWeight.bold, fontSize: 15)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _toFarsiDigits(int n) {
    const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    var s = n.toString();
    for (var i = 0; i < en.length; i++) {
      s = s.replaceAll(en[i], fa[i]);
    }
    return s;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.background,
      body: Column(
        children: [
          Expanded(
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  expandedHeight: 210,
                  pinned: false,
                  backgroundColor: C.background,
                  automaticallyImplyLeading: false,
                  flexibleSpace: FlexibleSpaceBar(
                    background: Padding(
                      padding: const EdgeInsets.fromLTRB(30, 16, 30, 10),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: C.blue.withOpacity(0.5), width: 1.4),
                          boxShadow: [BoxShadow(color: C.blue.withOpacity(0.25), blurRadius: 20)],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(19),
                          child: Image.asset('assets/logo.png', fit: BoxFit.cover),
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text('مستند صوتی شنود', style: TextStyle(color: C.blue, fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                        const SizedBox(height: 18),
                        const Text('فصل یک', style: TextStyle(color: C.white, fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 10),
                        for (var i = 1; i <= 16; i++) _buildPartCard(1, i),
                        const SizedBox(height: 16),
                        const Text('فصل دوم', style: TextStyle(color: C.white, fontSize: 16, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 10),
                        for (var i = 1; i <= 2; i++) _buildPartCard(2, i),
                        const SizedBox(height: 110),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomSheet: _current == null ? null : _buildPlayerBar(),
    );
  }

  Widget _buildPlayerBar() {
    final title = _current!.season == 1 ? 'فصل یک — قسمت ${_toFarsiDigits(_current!.part)}' : 'فصل دوم — قسمت ${_toFarsiDigits(_current!.part)}';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: const BoxDecoration(
        color: C.cardBg,
        border: Border(top: BorderSide(color: C.cardBorder)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(title, style: const TextStyle(color: C.blue, fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(onPressed: () => _seekBy(-10), icon: const Icon(Icons.replay_10, color: C.grayText, size: 26)),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () => _playTrack(_current!.season, _current!.part),
                  child: Container(
                    width: 52,
                    height: 52,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: C.blue),
                    child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.black, size: 28),
                  ),
                ),
                const SizedBox(width: 6),
                IconButton(onPressed: () => _seekBy(10), icon: const Icon(Icons.forward_10, color: C.grayText, size: 26)),
                const SizedBox(width: 6),
                IconButton(onPressed: _stopTrack, icon: const Icon(Icons.stop_circle_outlined, color: C.grayText, size: 26)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
