import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:vibration/vibration.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const ShonudApp());
}

/// -------------------- رنگ‌ها (آبی / سفید / مشکی) با حالت روز و شب --------------------
class AppColors {
  final Color background;
  final Color cardBg;
  final Color cardBorder;
  final Color accent;
  final Color accentDim;
  final Color textPrimary;
  final Color textSecondary;
  final Brightness brightness;

  const AppColors({
    required this.background,
    required this.cardBg,
    required this.cardBorder,
    required this.accent,
    required this.accentDim,
    required this.textPrimary,
    required this.textSecondary,
    required this.brightness,
  });

  static const night = AppColors(
    background: Color(0xFF0A0E14),
    cardBg: Color(0xFF121820),
    cardBorder: Color(0xFF223040),
    accent: Color(0xFF4FC3F7),
    accentDim: Color(0xFF2F6E8C),
    textPrimary: Color(0xFFF5F7FA),
    textSecondary: Color(0xFFAEB8C4),
    brightness: Brightness.dark,
  );

  static const day = AppColors(
    background: Color(0xFFF3F8FC),
    cardBg: Colors.white,
    cardBorder: Color(0xFFD3E6F1),
    accent: Color(0xFF1E88C7),
    accentDim: Color(0xFF6FAFD1),
    textPrimary: Color(0xFF162330),
    textSecondary: Color(0xFF5B6B78),
    brightness: Brightness.light,
  );
}

/// -------------------- مدل یک بلوکِ حدیث --------------------
class HadithBlock {
  final String? sectionTitle;
  final String? experiencerSummary;
  final String? narrator;
  final String? arabic;
  final String? farsi;
  final String? source;
  final String? note;
  const HadithBlock({
    this.sectionTitle,
    this.experiencerSummary,
    this.narrator,
    this.arabic,
    this.farsi,
    this.source,
    this.note,
  });
}

/// -------------------- حدیث‌های فصل یک --------------------
final Map<int, List<HadithBlock>> kSeason1Hadiths = {
  1: [
    HadithBlock(
      sectionTitle: 'دیدار و ارتباط روح با اموات و اجداد',
      experiencerSummary:
          'آقای صادق هنگام حرکت به سوی نور، صدای مادربزرگ و پدربزرگِ درگذشته‌اش را می‌شنود و حضور اجدادش را احساس می‌کند؛ آنها درباره‌ی آمدن او با یکدیگر صحبت می‌کردند و منتظر بودند بدانند چرا هنوز به آنها نرسیده است.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّ الْأَرْوَاحَ فِی صِفَةِ الْأَجْسَادِ فِی شَجَرَةٍ فِی الْجَنَّةِ، تَعَارَفُ وَتَسَاءَلُ، فَإِذَا قَدِمَتِ الرُّوحُ عَلَی الْأَرْوَاحِ قَالَتْ: دَعُوهَا فَإِنَّهَا قَدْ أَفْلَتَتْ مِنْ هَوْلٍ عَظِیمٍ، ثُمَّ یَسْأَلُونَهَا: مَا فَعَلَ فُلَانٌ وَمَا فَعَلَ فُلَانٌ؟',
      farsi:
          'همانا ارواح در جایگاهی در بهشت، یکدیگر را می‌شناسند و از حال هم پرس‌وجو می‌کنند. هنگامی که روحی نزد ارواح می‌آید، می‌گویند: او را رها کنید؛ زیرا از هول و هراس بزرگی رهایی یافته است. سپس از او می‌پرسند: فلانی چه کرد و فلانی چه کرد؟',
      source: 'الکافی، شیخ کلینی، ج ۳، ص ۲۴۴',
    ),
    HadithBlock(
      sectionTitle: 'مواجهه با ملک‌الموت و لحظه‌ی قبض روح',
      experiencerSummary:
          'او موجودی بسیار نورانی و باهیبت را می‌بیند که به او می‌فهماند برای گرفتن جانش آمده است؛ او را ملک‌الموت می‌داند و در برابرش کاملاً تسلیم می‌شود.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّهُ إِذَا أَتَاهُ مَلَکُ الْمَوْتِ لِقَبْضِ رُوحِهِ جَزِعَ عِنْدَ ذَلِکَ، فَیَقُولُ لَهُ مَلَکُ الْمَوْتِ: یَا وَلِیَّ اللَّهِ، لَا تَجْزَعْ...',
      farsi:
          'هنگامی که ملک‌الموت برای گرفتن روح مؤمن نزد او می‌آید، او در آن لحظه بی‌تاب می‌شود. پس ملک‌الموت به او می‌گوید: ای ولیّ خدا، بی‌تابی نکن...',
      source: 'الکافی، شیخ کلینی، ج ۳، ص ۱۲۷',
    ),
  ],
  2: [
    HadithBlock(
      sectionTitle: 'ارزش پنهان اعمال کوچک و نیت خالص',
      experiencerSummary:
          'تجربه‌گر در مرور اعمالش متوجه می‌شود بسیاری از کارهایی که اصلاً حسابشان نمی‌کرد، ارزش زیادی داشته‌اند؛ مانند کمک به مادر، جمع‌کردن رختخوابش و خریدن نان برایش. در مقابل، برخی کارهای بزرگش به‌دلیل نیت‌های غیرخالص، ارزشی برایش نداشتند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّمَا یَخْتَبِرُ اللَّهُ عَزَّ وَجَلَّ عِبَادَهُ لَا بِکَثْرَةِ الْعَمَلِ، وَلَکِنْ بِأَصْوَبِهِ، وَإِنَّمَا یُصَابُ بِالْإِخْلَاصِ، وَالنِّیَّةُ أَفْضَلُ مِنَ الْعَمَلِ.',
      farsi:
          'خداوند بندگانش را به زیادیِ عمل نمی‌آزماید، بلکه به درست و شایسته بودن عمل می‌آزماید؛ و عمل با اخلاص ارزش می‌یابد، و نیت از خودِ عمل برتر است.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الإخلاص، حدیث ۴',
      note: '(متن عربی این حدیث در منبع اصلی دارای ناهماهنگی بود و در این‌جا برای رفع تناقض، ویرایش جزئی شده است.)',
    ),
    HadithBlock(
      sectionTitle: 'نجات جان انسان و بیرون‌آوردن او از گمراهی',
      experiencerSummary:
          'آقای صادق در مرور اعمالش دید که نجاتِ جانِ چند نفر، از جمله جلوگیری از خودکشی یک نوجوان و نجات جوانی از کشته‌شدن، از اعمال ارزشمند او محسوب شده است.',
      narrator: 'امام محمد باقر علیه‌السلام',
      arabic: 'وَمَنْ أَحْیَاهَا فَکَأَنَّمَا أَحْیَا النَّاسَ جَمِیعًا...',
      farsi: 'هر کس انسانی را زنده کند، گویی همه‌ی مردم را زنده کرده است... (ادامه دارد)',
      source: 'الکافی، شیخ کلینی، ج ۲، باب «فی إحیاء المؤمن»',
    ),
  ],
  3: [
    HadithBlock(
      sectionTitle: 'خروج روح از بدن و بازگشت آن',
      experiencerSummary:
          'او خود را در گوشه‌ی سقف بیمارستان می‌بیند، بدن خودش را از بالا مشاهده می‌کند و نمی‌تواند به بدن بازگردد؛ سپس در ادامه دوباره وارد بدن می‌شود.',
      narrator: 'امام علی علیه‌السلام',
      arabic:
          'فَإِنَّ رُوحَ الْمُؤْمِنِ تُرْفَعُ إِلَی اللَّهِ تَبَارَکَ وَتَعَالَی فَیَقْبَلُهَا وَیُبَارِکُ عَلَیْهَا، فَإِنْ کَانَ أَجَلُهَا قَدْ حَضَرَ جَعَلَهَا فِی کُنُوزِ رَحْمَتِهِ، وَإِنْ لَمْ یَکُنْ أَجَلُهَا قَدْ حَضَرَ بَعَثَ بِهَا مَعَ أُمَنَائِهِ مِنْ مَلَائِکَتِهِ فَیَرُدُّونَهَا فِی جَسَدِهَا.',
      farsi:
          'روح مؤمن به‌سوی خدای تبارک و تعالی بالا برده می‌شود و خداوند آن را می‌پذیرد و بر آن برکت می‌دهد. اگر زمان مرگش فرا رسیده باشد، آن را در گنجینه‌های رحمت خود قرار می‌دهد؛ و اگر هنوز زمان مرگش نرسیده باشد، آن را به‌وسیله‌ی فرشتگان امین خود بازمی‌فرستد و آنان روح را به بدنش بازمی‌گردانند.',
      source: 'الخصال، شیخ صدوق',
    ),
  ],
  4: [
    HadithBlock(
      sectionTitle: 'مشاهده‌ی کربلا و نورانیت حرم امام حسین علیه‌السلام',
      experiencerSummary:
          'تجربه‌گر از مشاهده‌ی جهانی متفاوت سخن می‌گوید و کربلا و حرم امام حسین علیه‌السلام را به‌صورت جایگاهی بسیار نورانی و متفاوت از دیگر مکان‌ها مشاهده می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic: 'مَوْضِعُ قَبْرِ الْحُسَیْنِ عَلَیْهِ السَّلَامُ مُنْذُ یَوْمِ دُفِنَ فِیهِ رَوْضَةٌ مِنْ رِیَاضِ الْجَنَّةِ.',
      farsi: 'جایگاه قبر حسین علیه‌السلام از همان روزی که در آن دفن شد، باغی از باغ‌های بهشت است.',
      source: 'من لا یحضره الفقیه، شیخ صدوق، ج ۲، ص ۲۲۹',
    ),
  ],
  5: [
    HadithBlock(
      sectionTitle: 'حمله‌ی شیاطین و پناه‌بردن به ذکر خدا',
      experiencerSummary:
          'آقای صادق در حالت نزدیک به مرگ، موجودات وحشتناکی را می‌بیند که به‌شدت به او حمله می‌کنند و حتی زبانش از ترس قفل می‌شود. با توسل به حضرت زهرا و اهل‌بیت و گفتن ذکرهایی مانند «بسم‌الله الرحمن الرحیم» و «لا حول ولا قوة إلا بالله العلی العظیم»، می‌بیند که آنها از او فاصله می‌گیرند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ أَحَدٍ یَحْضُرُهُ الْمَوْتُ إِلَّا وَکَّلَ بِهِ إِبْلِیسُ مِنْ شَیَاطِینِهِ مَنْ یَأْمُرُهُ بِالْکُفْرِ وَیُشَکِّکُهُ فِی دِینِهِ حَتَّی تَخْرُجَ نَفْسُهُ، فَمَنْ کَانَ مُؤْمِنًا لَمْ یَقْدِرْ عَلَیْهِ...',
      farsi:
          'هیچ‌کس نیست که مرگش فرا برسد، مگر اینکه ابلیس یکی از شیاطینش را بر او می‌گمارد تا او را به کفر بکشاند و در دینش دچار تردید کند تا جانش از بدن بیرون رود؛ اما اگر مؤمن باشد، شیطان نمی‌تواند بر او غلبه کند...',
      source: 'الکافی، شیخ کلینی، ج ۳، باب «ما یعاین المؤمن والکافر عند الموت»',
    ),
  ],
  6: [
    HadithBlock(
      sectionTitle: 'تلاش شیطان برای منحرف‌کردن انسان در آخرین لحظات عمر',
      experiencerSummary:
          'آقای صادق می‌گوید شیاطین در هنگام مرگ تلاش می‌کنند انسان متوجه خدا نشود و با ایجاد سرگرمی و بهانه، او را از توسل و توجه به خدا دور کنند. او این مسئله را هنگام مشاهده‌ی یک پیرمرد در حال مرگ نیز شرح می‌دهد.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ أَحَدٍ یَحْضُرُهُ الْمَوْتُ إِلَّا وَکَّلَ بِهِ إِبْلِیسُ مِنْ شَیَاطِینِهِ مَنْ یَأْمُرُهُ بِالْکُفْرِ وَیُشَکِّکُهُ فِی دِینِهِ حَتَّی تَخْرُجَ نَفْسُهُ، فَمَنْ کَانَ مُؤْمِنًا لَمْ یَقْدِرْ عَلَیْهِ.',
      farsi:
          'وقتی مرگ انسان فرا می‌رسد، ابلیس یکی از شیاطینش را بر او می‌گمارد تا او را به کفر دعوت کند و در دینش به تردید بیندازد تا جانش از بدن بیرون برود؛ اما اگر مؤمن باشد، شیطان نمی‌تواند بر او چیره شود.',
      source: 'الکافی، شیخ کلینی، ج ۳، باب «ما یعاین المؤمن والکافر عند الموت»',
    ),
  ],
  7: [
    HadithBlock(
      sectionTitle: 'وسوسه‌ی شیطان و نجوا در گوش انسان',
      experiencerSummary:
          'آقای صادق شیطان را موجودی توصیف می‌کند که در کنار انسان قرار می‌گیرد و با وسوسه و توجیه، انسان را از توجه به خدا و انجام کار درست دور می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'مَا مِنْ قَلْبٍ إِلَّا وَلَهُ أُذُنَانِ، عَلَی إِحْدَاهُمَا مَلَکٌ مُرْشِدٌ، وَعَلَی الْأُخْرَی شَیْطَانٌ مُفْتِنٌ، هَذَا یَأْمُرُهُ وَهَذَا یَزْجُرُهُ، الشَّیْطَانُ یَأْمُرُهُ بِالْمَعَاصِی، وَالْمَلَکُ یَزْجُرُهُ عَنْهَا.',
      farsi:
          'هر قلبی دو گوش دارد؛ بر یکی فرشته‌ای راهنماست و بر دیگری شیطانی وسوسه‌گر. یکی فرمان می‌دهد و دیگری بازمی‌دارد؛ شیطان انسان را به گناه دعوت می‌کند و فرشته او را از آن بازمی‌دارد.',
      source: 'الکافی، شیخ کلینی، ج ۲',
    ),
  ],
  9: [
    HadithBlock(
      sectionTitle: 'خشم و نقش شیطان در تحریک انسان',
      experiencerSummary:
          'در مشاهداتش، ارتباط میان خشم شدید انسان و حضور شیطان را توصیف می‌کند و می‌گوید شیطان می‌تواند از خشم انسان برای تحریک رفتار و خارج‌کردن او از کنترل استفاده کند.',
      narrator: 'امام محمد باقر علیه‌السلام',
      arabic:
          'إِنَّ هَذَا الْغَضَبَ جَمْرَةٌ مِنَ الشَّیْطَانِ تُوقَدُ فِی قَلْبِ ابْنِ آدَمَ، وَإِنَّ أَحَدَکُمْ إِذَا غَضِبَ احْمَرَّتْ عَیْنَاهُ، وَانْتَفَخَتْ أَوْدَاجُهُ، وَدَخَلَ الشَّیْطَانُ فِیهِ...',
      farsi:
          'این خشم، شراره‌ای از شیطان است که در قلب فرزند آدم افروخته می‌شود. هنگامی که یکی از شما خشمگین می‌شود، چشمانش سرخ و رگ‌هایش متورم می‌شود و شیطان در او وارد می‌شود...',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الغضب',
    ),
  ],
  10: [
    HadithBlock(
      sectionTitle: 'اثر اعمال انسان بر دیگران و حق‌الناس',
      experiencerSummary:
          'آقای صادق در مرور اعمالش می‌بیند بعضی رفتارها و زخم‌زبان‌هایی که در دنیا کم‌اهمیت می‌دانسته، آثار واقعی داشته‌اند و انسان نسبت به پیامد رفتار خود در برابر دیگران مسئول است.',
      narrator: 'امام صادق علیه‌السلام',
      arabic: 'مَنْ ظَلَمَ مَظْلِمَةً أُخِذَ بِهَا فِی نَفْسِهِ أَوْ فِی مَالِهِ أَوْ فِی وُلْدِهِ.',
      farsi: 'هر کس به دیگری ستمی کند، به سبب آن ستم مؤاخذه خواهد شد؛ در جانش یا مالش یا فرزندش.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الظلم',
    ),
  ],
  11: [
    HadithBlock(
      sectionTitle: 'باقی‌ماندن آثار عمل انسان پس از مرگ',
      experiencerSummary:
          'آقای صادق توضیح می‌دهد برخی رفتارهای انسان فقط به لحظه‌ی انجامشان محدود نمی‌شوند و آثار خیر آنها می‌تواند پس از مرگ نیز ادامه پیدا کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'لَیْسَ یَتْبَعُ الرَّجُلَ بَعْدَ مَوْتِهِ مِنَ الْأَجْرِ إِلَّا ثَلَاثُ خِصَالٍ: صَدَقَةٌ أَجْرَاهَا فِی حَیَاتِهِ فَهِیَ تَجْرِی بَعْدَ مَوْتِهِ، وَسُنَّةُ هُدًی سَنَّهَا فَهِیَ یُعْمَلُ بِهَا بَعْدَ مَوْتِهِ، أَوْ وَلَدٌ صَالِحٌ یَدْعُو لَهُ.',
      farsi:
          'پس از مرگ انسان، پاداش سه چیز همچنان به او می‌رسد: صدقه‌ای که در زندگی انجام داده و پس از مرگش ادامه دارد؛ راه و روش هدایتی که پایه گذاشته و بعد از مرگش به آن عمل می‌شود؛ یا فرزند صالحی که برای او دعا می‌کند.',
      source: 'الکافی، شیخ کلینی، ج ۷، باب «ما یلحق المیت بعد موته»',
    ),
  ],
  12: [
    HadithBlock(
      sectionTitle: 'اثر گناه و پاک‌شدن آن با توبه',
      experiencerSummary:
          'او گناه را دارای اثری واقعی می‌داند که می‌تواند بر انسان باقی بماند و توبه را سبب پاک‌شدن این آثار معرفی می‌کند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِذَا أَذْنَبَ الرَّجُلُ خَرَجَ فِی قَلْبِهِ نُکْتَةٌ سَوْدَاءُ، فَإِنْ تَابَ انْمَحَتْ، وَإِنْ زَادَ زَادَتْ حَتَّی تَغْلِبَ عَلَی قَلْبِهِ فَلَا یُفْلِحُ بَعْدَهَا أَبَدًا.',
      farsi:
          'هرگاه انسان گناهی مرتکب شود، نقطه‌ای سیاه در قلبش پدید می‌آید؛ اگر توبه کند، آن نقطه پاک می‌شود؛ و اگر بر گناه بیفزاید، آن نقطه بیشتر می‌شود تا جایی که بر قلبش غلبه کند.',
      source: 'الکافی، شیخ کلینی، ج ۲، کتاب الإیمان والکفر، باب الذنوب',
    ),
  ],
  13: [
    HadithBlock(
      sectionTitle: 'حضور سپاه فرشتگان در یاری قائم آل‌محمد علیهم‌السلام',
      experiencerSummary:
          'آقای صادق در مشاهدات خود سپاهی عظیم از فرشتگان را می‌بیند که مسلح و آماده‌اند و درباره‌ی مأموریت آنها برای یاری جبهه‌ی حق و حضرت صاحب‌الزمان عجل‌الله‌تعالی‌فرجه صحبت می‌شود.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'فَیَنْحَطُّ عَلَیْهِ ثَلَاثَةَ عَشَرَ أَلْفَ مَلَکٍ وَثَلَاثَ مِائَةٍ وَثَلَاثَةَ عَشَرَ مَلَکًا. قُلْتُ: کُلُّ هَؤُلَاءِ الْمَلَائِکَةِ؟ قَالَ: نَعَمْ، الَّذِینَ کَانُوا مَعَ نُوحٍ فِی السَّفِینَةِ، وَالَّذِینَ کَانُوا مَعَ إِبْرَاهِیمَ حِینَ أُلْقِیَ فِی النَّارِ، وَالَّذِینَ کَانُوا مَعَ مُوسَی حِینَ فَلَقَ الْبَحْرَ لِبَنِی إِسْرَائِیلَ، وَالَّذِینَ کَانُوا مَعَ عِیسَی حِینَ رَفَعَهُ اللَّهُ إِلَیْهِ، وَأَرْبَعَةُ آلَافِ مَلَکٍ مَعَ النَّبِیِّ صَلَّی اللَّهُ عَلَیْهِ وَآلِهِ مُسَوَّمِینَ، وَأَلْفٌ مُرْدِفِینَ، وَثَلَاثَةُ مِائَةٍ وَثَلَاثَةَ عَشَرَ مَلَکًا بَدْرِیِّینَ، وَأَرْبَعَةُ آلَافِ مَلَکٍ هَبَطُوا یُرِیدُونَ الْقِتَالَ مَعَ الْحُسَیْنِ عَلَیْهِ السَّلَامُ.',
      farsi:
          'سیزده هزار و سیصد و سیزده فرشته بر او (حضرت حجت) فرود می‌آیند. پرسیدم: همه‌ی این فرشتگان؟ فرمود: آری؛ همان فرشتگانی که با نوح در کشتی بودند، با ابراهیم هنگامی که او را در آتش افکندند، با موسی هنگامی که دریا را برای بنی‌اسرائیل شکافت، و با عیسی هنگامی که خدا او را به‌سوی خود بالا برد. هم‌چنین چهار هزار فرشته که با پیامبر صلی‌الله‌علیه‌وآله بودند، و فرشتگان جنگ بدر، و چهار هزار فرشته که برای جنگیدن در کنار حسین علیه‌السلام فرود آمدند.',
      source: 'کمال‌الدین و تمام النعمة، شیخ صدوق؛ بحارالانوار، علامه مجلسی، ج ۵۲',
      note: '(اصل روایت معتبر است؛ شماره‌ها و منبع دقیق در نسخه‌های مختلف اندکی متفاوت نقل شده و این‌جا یکدست شده است.)',
    ),
  ],
};

/// حدیث فصل دوم (فقط قسمت اول موجود است)
final Map<int, List<HadithBlock>> kSeason2Hadiths = {
  1: [
    HadithBlock(
      sectionTitle: 'ادراک روحانی و لذت‌های گسترده‌تر در عالم دیگر',
      experiencerSummary:
          'آقای صادق توضیح می‌دهد که در عالم روحانی، ادراک انسان دیگر محدود به حواس جسمانی نیست؛ روح می‌تواند لذت‌ها و زیبایی‌هایی را درک کند که در دنیا قابل مقایسه با آنها نیست و این لذت‌ها برایش محدود و تکراری نمی‌شوند.',
      narrator: 'امام صادق علیه‌السلام',
      arabic:
          'إِنَّ اللَّهَ خَلَقَ بِیَدِهِ جَنَّةً لَمْ یَرَهَا عَیْنٌ، وَلَمْ یَطَّلِعْ عَلَیْهَا مَخْلُوقٌ، یَفْتَحُهَا الرَّبُّ تَبَارَکَ وَتَعَالَی کُلَّ صَبَاحٍ فَیَقُولُ: ازْدَادِی طِیبًا، ازْدَادِی رِیحًا، فَتَقُولُ: قَدْ أَفْلَحَ الْمُؤْمِنُونَ.',
      farsi:
          'خداوند به‌دست قدرت خود بهشتی آفریده که هیچ چشمی آن را ندیده و هیچ آفریده‌ای از آن آگاهی نیافته است. پروردگار هر صبح آن را می‌گشاید و به آن می‌فرماید: بر زیبایی و عطر و طراوتت بیفزا. و آن بهشت می‌گوید: مؤمنان رستگار شدند.',
      source: 'کتاب الزهد، شیخ حسین بن سعید اهوازی، باب «صفات الجنة والنار»، حدیث ۱۱',
    ),
  ],
};

/// -------------------- اپ --------------------
/// -------------------- جلسات پرسش و پاسخ (دانلودی) --------------------
class QnaItem {
  final int part;
  final String url;
  const QnaItem(this.part, this.url);
}

const List<QnaItem> kQnaItems = [
  QnaItem(1, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/01 Porsesh Va Pasokh Mosianade Soti Shonood (1401-03-26) (1).mp3'),
  QnaItem(2, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/02 Porsesh Va Pasokh Mosianade Soti Shonood (1401-03-26).mp3'),
  QnaItem(3, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/03 Porsesh Va Pasokh Mosianade Soti Shonood (1401-03-26).mp3'),
  QnaItem(4, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/04_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
  QnaItem(5, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/05_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
  QnaItem(6, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/06_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
  QnaItem(7, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/07_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
  QnaItem(8, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/08_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
  QnaItem(9, 'https://skystorage.ir/Applications/SafeCloud/User/0209caf8285358e0/09_Porsesh_Pasokh_Mostanade_Soti_Shonood_Aminikhaah.ir.mp3'),
];

/// -------------------- منابع --------------------
class SourceItem {
  final String title;
  final String subtitle;
  final String url;
  const SourceItem(this.title, this.subtitle, this.url);
}

const List<SourceItem> kSourceItems = [
  SourceItem('وب‌سایت رسمی مستند صوتی شنود', 'shonoud.com', 'https://shonoud.com'),
  SourceItem('وب‌سایت حجت‌الاسلام والمسلمین مصطفی امینی‌خواه', 'aminikhaah.ir', 'https://aminikhaah.ir'),
  SourceItem('کانال رسمی مستند صوتی شنود (تلگرام)', '@ShonoudMedia', 'https://t.me/ShonoudMedia'),
  SourceItem('کانال رسمی مستند صوتی شنود (ایتا)', '@ShonoudMedia', 'https://eitaa.com/ShonoudMedia'),
];

class ShonudApp extends StatefulWidget {
  const ShonudApp({super.key});
  @override
  State<ShonudApp> createState() => _ShonudAppState();
}

class _ShonudAppState extends State<ShonudApp> {
  bool _nightMode = true;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _nightMode = prefs.getBool('nightMode') ?? true;
      _loaded = true;
    });
  }

  void _toggleNightMode() async {
    setState(() => _nightMode = !_nightMode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nightMode', _nightMode);
  }

  @override
  Widget build(BuildContext context) {
    final colors = _nightMode ? AppColors.night : AppColors.day;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: _nightMode ? Brightness.light : Brightness.dark,
        systemNavigationBarColor: colors.background,
        systemNavigationBarIconBrightness: _nightMode ? Brightness.light : Brightness.dark,
        systemNavigationBarDividerColor: colors.background,
      ),
      child: MaterialApp(
        title: 'شنود',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: colors.brightness,
          scaffoldBackgroundColor: colors.background,
          colorScheme: ColorScheme.fromSeed(
            seedColor: colors.accent,
            brightness: colors.brightness,
          ),
          bottomSheetTheme: BottomSheetThemeData(backgroundColor: colors.cardBg),
        ),
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        home: _loaded
            ? HomeScreen(colors: colors, nightMode: _nightMode, onToggleNightMode: _toggleNightMode)
            : Container(color: colors.background),
      ),
    );
  }
}

/// -------------------- شناسه‌ی یک قسمتِ درحال پخش --------------------
class PlayingTrack {
  final int season;
  final int part;
  const PlayingTrack(this.season, this.part);
  @override
  bool operator ==(Object other) => other is PlayingTrack && other.season == season && other.part == part;
  @override
  int get hashCode => Object.hash(season, part);
}

/// -------------------- ورودی نرم و پلکانی برای هر آیتم لیست --------------------
class StaggeredFadeIn extends StatefulWidget {
  final int index;
  final Widget child;
  const StaggeredFadeIn({super.key, required this.index, required this.child});

  @override
  State<StaggeredFadeIn> createState() => _StaggeredFadeInState();
}

class _StaggeredFadeInState extends State<StaggeredFadeIn> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 420));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(begin: const Offset(0, 0.10), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    final delay = Duration(milliseconds: 28 * widget.index);
    Future.delayed(delay, () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide, child: widget.child),
    );
  }
}

/// -------------------- صفحه اصلی --------------------
class HomeScreen extends StatefulWidget {
  final AppColors colors;
  final bool nightMode;
  final VoidCallback onToggleNightMode;
  const HomeScreen({
    super.key,
    required this.colors,
    required this.nightMode,
    required this.onToggleNightMode,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  final AudioPlayer _player = AudioPlayer();
  PlayingTrack? _current;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _menuOpen = false;
  int _menuTab = 0; // 0 = مستند شنود (متن), 1 = جلسات پرسش و پاسخ, 2 = منابع
  final Map<int, double> _qnaProgress = {};
  Set<int> _qnaDownloaded = {};
  Map<String, int> _savedPositionSec = {};
  Set<String> _completedTracks = {};
  late final AnimationController _pulseCtrl;

  AppColors get c => widget.colors;

  String _posKey(int season, int part) => 's${season}_p$part';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _player.onPlayerComplete.listen((_) => _onTrackComplete());
    _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _position = p);
      if (_current != null && p.inSeconds > 0 && p.inSeconds % 5 == 0) {
        _savePosition(_current!, p.inSeconds);
      }
    });
    _player.onDurationChanged.listen((d) {
      if (mounted) setState(() => _duration = d);
    });
    _scanQnaDownloads();
    _loadSavedProgress();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      _persistCurrentPositionNow();
    }
  }

  Future<void> _persistCurrentPositionNow() async {
    if (_current == null) return;
    try {
      final pos = await _player.getCurrentPosition();
      if (pos != null && pos.inSeconds > 0) {
        await _savePosition(_current!, pos.inSeconds);
      }
    } catch (_) {}
  }

  Future<void> _loadSavedProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = <String>[];
    for (var p = 1; p <= 16; p++) keys.add(_posKey(1, p));
    for (var p = 1; p <= 2; p++) keys.add(_posKey(2, p));
    for (var p = 1; p <= 9; p++) keys.add(_posKey(3, p));
    final pos = <String, int>{};
    final done = <String>{};
    for (final key in keys) {
      final v = prefs.getInt('pos_$key');
      if (v != null) pos[key] = v;
      if (prefs.getBool('done_$key') == true) done.add(key);
    }
    if (mounted) setState(() { _savedPositionSec = pos; _completedTracks = done; });
  }

  Future<void> _savePosition(PlayingTrack t, int seconds) async {
    final key = _posKey(t.season, t.part);
    _savedPositionSec[key] = seconds;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('pos_$key', seconds);
  }

  Future<void> _onTrackComplete() async {
    if (mounted) setState(() { _isPlaying = false; _position = Duration.zero; });
    if (_current == null) return;
    final key = _posKey(_current!.season, _current!.part);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('done_$key', true);
    await prefs.remove('pos_$key');
    if (mounted) {
      setState(() {
        _completedTracks.add(key);
        _savedPositionSec.remove(key);
      });
    }
  }

  /// اگر پیش‌تر تا جایی از این قسمت گوش داده شده، از کاربر می‌پرسد که از
  /// همان‌جا ادامه بدهد یا از اول شروع کند؛ در غیر این صورت از اول پخش می‌شود.
  Future<int> _resolveStartSeconds(int season, int part) async {
    final key = _posKey(season, part);
    if (_completedTracks.contains(key)) return 0;
    final saved = _savedPositionSec[key];
    if (saved == null || saved < 10) return 0;
    final resume = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: c.cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('ادامه‌ی پخش', style: TextStyle(color: c.textPrimary, fontSize: 15)),
        content: Text(
          'این قسمت تا ${_fmt(Duration(seconds: saved))} شنیده شده. می‌خواهید از همان‌جا ادامه دهید؟',
          style: TextStyle(color: c.textSecondary, fontSize: 13),
        ),
        actionsAlignment: MainAxisAlignment.spaceBetween,
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('از اول')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text('ادامه', style: TextStyle(color: c.accent, fontWeight: FontWeight.bold))),
        ],
      ),
    );
    return resume == true ? saved : 0;
  }

  Future<String> _qnaFilePath(int part) async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/qna_part$part.mp3';
  }

  Future<void> _scanQnaDownloads() async {
    final found = <int>{};
    for (final item in kQnaItems) {
      final path = await _qnaFilePath(item.part);
      if (await File(path).exists()) found.add(item.part);
    }
    if (mounted) setState(() => _qnaDownloaded = found);
  }

  Future<void> _downloadQna(int part) async {
    if (_qnaProgress.containsKey(part)) return;
    _vibrate();
    final item = kQnaItems.firstWhere((e) => e.part == part);
    setState(() => _qnaProgress[part] = 0.0);
    try {
      final uri = Uri.parse(Uri.encodeFull(item.url));
      final request = http.Request('GET', uri);
      final response = await http.Client().send(request);
      final total = response.contentLength ?? 0;
      var received = 0;
      final path = await _qnaFilePath(part);
      final sink = File(path).openWrite();
      await response.stream.listen((chunk) {
        received += chunk.length;
        sink.add(chunk);
        if (total > 0 && mounted) {
          setState(() => _qnaProgress[part] = received / total);
        }
      }).asFuture<void>();
      await sink.close();
      if (mounted) {
        setState(() {
          _qnaProgress.remove(part);
          _qnaDownloaded.add(part);
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _qnaProgress.remove(part));
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('دانلود با خطا مواجه شد. دوباره تلاش کنید.')),
        );
      }
    }
  }

  Future<void> _deleteQna(int part) async {
    _vibrate();
    final path = await _qnaFilePath(part);
    final file = File(path);
    if (await file.exists()) await file.delete();
    if (_current == PlayingTrack(3, part)) {
      await _stopTrack();
    }
    if (mounted) setState(() => _qnaDownloaded.remove(part));
  }

  Future<void> _playQna(int part) async {
    _vibrate();
    final trackId = PlayingTrack(3, part);
    if (_current == trackId) {
      if (_isPlaying) {
        final pos = await _player.getCurrentPosition();
        await _player.pause();
        if (pos != null && pos.inSeconds > 0) await _savePosition(trackId, pos.inSeconds);
        setState(() => _isPlaying = false);
      } else {
        await _player.resume();
        setState(() => _isPlaying = true);
      }
      return;
    }
    final path = await _qnaFilePath(part);
    await _player.stop();
    final startSec = await _resolveStartSeconds(3, part);
    await _player.play(DeviceFileSource(path));
    if (startSec > 0) await _player.seek(Duration(seconds: startSec));
    setState(() {
      _current = trackId;
      _isPlaying = true;
      _position = Duration(seconds: startSec);
      _duration = Duration.zero;
    });
    _pollDurationFallback(trackId);
  }

  Future<void> _openUrl(String url) async {
    _vibrate();
    final uri = Uri.parse(url);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('امکان باز کردن این لینک وجود نداشت.')),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _player.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _vibrate() async {
    try {
      if (await Vibration.hasVibrator()) {
        Vibration.vibrate(duration: 18, amplitude: 120);
        return;
      }
    } catch (_) {}
    HapticFeedback.selectionClick();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String _assetFor(int season, int part) {
    if (season == 1) return 'audio/mostanad_soti_shonud_part$part.mp3';
    return 'audio/mostanad_soti_shonud_s2_part$part.mp3';
  }

  String _pdfAssetFor(int season, int part) {
    if (season == 1) return 'assets/pdf/mostanad_soti_shonud_part$part.pdf';
    return 'assets/pdf/mostanad_soti_shonud_s2_part$part.pdf';
  }

  Future<void> _openTranscript(int season, int part) async {
    _vibrate();
    try {
      final byteData = await DefaultAssetBundle.of(context).load(_pdfAssetFor(season, part));
      final tempDir = await getTemporaryDirectory();
      final fileName = season == 1 ? 'part$part.pdf' : 's2_part$part.pdf';
      final file = File('${tempDir.path}/$fileName');
      await file.writeAsBytes(byteData.buffer.asUint8List(), flush: true);
      await OpenFile.open(file.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('متن این قسمت هنوز اضافه نشده است.')),
        );
      }
    }
  }

  Future<void> _playTrack(int season, int part) async {
    _vibrate();
    if (_current == PlayingTrack(season, part)) {
      if (_isPlaying) {
        final pos = await _player.getCurrentPosition();
        await _player.pause();
        if (pos != null && pos.inSeconds > 0) await _savePosition(PlayingTrack(season, part), pos.inSeconds);
        setState(() => _isPlaying = false);
      } else {
        await _player.resume();
        setState(() => _isPlaying = true);
      }
      return;
    }
    await _player.stop();
    final startSec = await _resolveStartSeconds(season, part);
    await _player.play(AssetSource(_assetFor(season, part)));
    if (startSec > 0) await _player.seek(Duration(seconds: startSec));
    setState(() {
      _current = PlayingTrack(season, part);
      _isPlaying = true;
      _position = Duration(seconds: startSec);
      _duration = Duration.zero;
    });
    _pollDurationFallback(PlayingTrack(season, part));
  }

  /// بعضی گوشی‌ها/کدک‌ها با تأخیر duration رو گزارش می‌دن یا اصلاً از
  /// طریق استریم onDurationChanged چیزی نمی‌فرستن؛ برای اطمینان روی همه‌ی
  /// دستگاه‌ها، چندبار با تأخیر مستقیم هم درخواست duration می‌کنیم.
  Future<void> _pollDurationFallback(PlayingTrack track) async {
    for (final delay in [300, 800, 1500, 3000]) {
      await Future.delayed(Duration(milliseconds: delay));
      if (!mounted || _current != track) return;
      if (_duration.inSeconds > 0) return;
      try {
        final d = await _player.getDuration();
        if (d != null && d.inSeconds > 0 && mounted && _current == track) {
          setState(() => _duration = d);
          return;
        }
      } catch (_) {}
    }
  }

  Future<void> _stopTrack() async {
    _vibrate();
    if (_current != null) {
      try {
        final pos = await _player.getCurrentPosition();
        if (pos != null && pos.inSeconds > 0) await _savePosition(_current!, pos.inSeconds);
      } catch (_) {}
    }
    await _player.stop();
    setState(() {
      _isPlaying = false;
      _current = null;
      _position = Duration.zero;
      _duration = Duration.zero;
    });
  }

  Future<void> _seekBy(int seconds) async {
    _vibrate();
    final pos = await _player.getCurrentPosition() ?? Duration.zero;
    var target = pos + Duration(seconds: seconds);
    if (target < Duration.zero) target = Duration.zero;
    await _player.seek(target);
  }

  void _openHadithSheet(int season, int part) {
    _vibrate();
    final list = season == 1 ? kSeason1Hadiths[part] : kSeason2Hadiths[part];
    showModalBottomSheet(
      context: context,
      backgroundColor: c.cardBg,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          minChildSize: 0.4,
          maxChildSize: 0.92,
          expand: false,
          builder: (context, scrollController) {
            return Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: c.cardBorder))),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 10),
                        decoration: BoxDecoration(color: c.accent.withOpacity(0.4), borderRadius: BorderRadius.circular(4)),
                      ),
                      Text('حدیث‌های مرتبط', style: TextStyle(color: c.accent, fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                ),
                Expanded(
                  child: (list == null || list.isEmpty)
                      ? const SizedBox.shrink()
                      : ListView.builder(
                          controller: scrollController,
                          padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
                          itemCount: list.length,
                          itemBuilder: (context, i) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _buildHadithBlock(list[i]),
                                if (i != list.length - 1) _buildDivider(),
                              ],
                            );
                          },
                        ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildDivider() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Row(
        children: [
          Expanded(child: Container(height: 1, color: c.cardBorder)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text('\u262B', style: TextStyle(fontSize: 18, color: c.accent)),
          ),
          Expanded(child: Container(height: 1, color: c.cardBorder)),
        ],
      ),
    );
  }

  Widget _buildHadithBlock(HadithBlock h) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (h.sectionTitle != null) ...[
          Row(
            children: [
              Icon(Icons.brightness_1, size: 7, color: c.accent),
              const SizedBox(width: 8),
              Expanded(child: Text(h.sectionTitle!, style: TextStyle(color: c.accent, fontWeight: FontWeight.bold, fontSize: 14.5))),
            ],
          ),
          const SizedBox(height: 10),
        ],
        if (h.experiencerSummary != null) ...[
          Text('خلاصه‌ی حرف‌های تجربه‌گر:', style: TextStyle(color: c.textSecondary, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(h.experiencerSummary!, textAlign: TextAlign.justify, style: TextStyle(color: c.textSecondary, fontSize: 12.5, height: 1.8, fontStyle: FontStyle.italic)),
          const SizedBox(height: 14),
        ],
        if (h.arabic != null) ...[
          if (h.narrator != null) ...[
            Text(h.narrator!, style: TextStyle(color: c.textPrimary, fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 8),
          ],
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: c.background,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: c.accentDim),
            ),
            child: Text(h.arabic!, textAlign: TextAlign.center, style: TextStyle(color: c.textPrimary, fontSize: 15.5, height: 1.9)),
          ),
          const SizedBox(height: 10),
        ],
        if (h.farsi != null) ...[
          Text('ترجمه‌ی فارسی:', style: TextStyle(color: c.textSecondary, fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(h.farsi!, textAlign: TextAlign.justify, style: TextStyle(color: c.textSecondary, fontSize: 12.5, height: 1.85)),
        ],
        if (h.source != null) ...[
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: Text('منبع: ${h.source!}', style: TextStyle(color: c.accentDim, fontSize: 11)),
          ),
        ],
        if (h.note != null) ...[
          const SizedBox(height: 6),
          Text(h.note!, textAlign: TextAlign.center, style: TextStyle(color: c.accentDim, fontSize: 10.5, fontStyle: FontStyle.italic)),
        ],
      ],
    );
  }

  String _toFarsiDigits(int n) {
    const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    var s = n.toString();
    for (var i = 0; i < en.length; i++) {
      s = s.replaceAll(en[i], fa[i]);
    }
    return s;
  }

  Widget _buildPartCard(int season, int part) {
    final isThis = _current == PlayingTrack(season, part);
    final playingHere = isThis && _isPlaying;
    final key = _posKey(season, part);
    final isDone = _completedTracks.contains(key);
    final savedSec = _savedPositionSec[key];
    String? statusText;
    if (isDone) {
      statusText = '✓ شنیده شد';
    } else if (savedSec != null && savedSec >= 10) {
      statusText = '▶ ادامه از ${_fmt(Duration(seconds: savedSec))}';
    }
    return Center(
      child: FractionallySizedBox(
        widthFactor: 0.86,
        child: GestureDetector(
          onTap: () => _playTrack(season, part),
          child: AnimatedScale(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            scale: playingHere ? 1.03 : 1.0,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              margin: const EdgeInsets.only(bottom: 12),
              padding: EdgeInsets.symmetric(vertical: statusText == null ? 0 : 6),
              constraints: const BoxConstraints(minHeight: 56),
              decoration: BoxDecoration(
                color: isThis ? c.accent.withOpacity(0.10) : c.cardBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isThis ? c.accent : c.cardBorder, width: isThis ? 1.4 : 1),
                boxShadow: playingHere
                    ? [BoxShadow(color: c.accent.withOpacity(0.28), blurRadius: 14, spreadRadius: 1)]
                    : [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 6)],
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            playingHere
                                ? FadeTransition(
                                    opacity: Tween<double>(begin: 0.4, end: 1.0).animate(_pulseCtrl),
                                    child: Icon(Icons.graphic_eq, color: c.accent, size: 19),
                                  )
                                : Icon(Icons.play_circle_outline, color: c.textSecondary, size: 18),
                            const SizedBox(width: 9),
                            Text(
                              'قسمت ${_toFarsiDigits(part)}',
                              style: TextStyle(
                                color: isThis ? c.accent : c.textPrimary,
                                fontWeight: isThis ? FontWeight.bold : FontWeight.w600,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                        if (statusText != null) ...[
                          const SizedBox(height: 3),
                          Text(
                            statusText,
                            style: TextStyle(
                              color: isDone ? c.accentDim : c.accent.withOpacity(0.85),
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  Positioned(
                    top: 6,
                    left: 6,
                    child: GestureDetector(
                      onTap: () => _openHadithSheet(season, part),
                      child: Container(
                        width: 18,
                        height: 18,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: c.accent.withOpacity(0.14),
                          border: Border.all(color: c.accent.withOpacity(0.6), width: 0.8),
                        ),
                        child: Text('!', style: TextStyle(color: c.accent, fontWeight: FontWeight.bold, fontSize: 9)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _buildListItems() {
    final items = <Map<String, dynamic>>[];
    items.add({'type': 'header', 'text': 'فصل یک'});
    for (var i = 1; i <= 16; i++) {
      items.add({'type': 'card', 'season': 1, 'part': i});
    }
    items.add({'type': 'header', 'text': 'فصل دوم'});
    for (var i = 1; i <= 2; i++) {
      items.add({'type': 'card', 'season': 2, 'part': i});
    }
    items.add({'type': 'spacer'});
    return items;
  }

  @override
  Widget build(BuildContext context) {
    final items = _buildListItems();

    return Scaffold(
      backgroundColor: c.background,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenWidth = constraints.maxWidth;
          final panelWidth = screenWidth / 3 < 190 ? 190.0 : screenWidth / 3;
          return Stack(
        children: [
          CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverAppBar(
                expandedHeight: 290,
                pinned: false,
                stretch: true,
                backgroundColor: c.background,
                automaticallyImplyLeading: false,
                flexibleSpace: FlexibleSpaceBar(
                  stretchModes: const [StretchMode.zoomBackground],
                  background: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 14, 20, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () => setState(() => _menuOpen = true),
                              child: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: c.cardBg,
                                  border: Border.all(color: c.cardBorder),
                                ),
                                child: Icon(Icons.menu, color: c.accent, size: 22),
                              ),
                            ),
                            GestureDetector(
                              onTap: widget.onToggleNightMode,
                              child: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: c.cardBg,
                                  border: Border.all(color: c.cardBorder),
                                ),
                                child: Icon(
                                  widget.nightMode ? Icons.dark_mode : Icons.light_mode,
                                  color: c.accent,
                                  size: 24,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: c.accent.withOpacity(0.5), width: 1.4),
                              boxShadow: [BoxShadow(color: c.accent.withOpacity(0.22), blurRadius: 18)],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(19),
                              child: Image.asset('assets/bala.png', fit: BoxFit.cover, width: double.infinity),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    'شنود',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: c.accent, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final item = items[index];
                      if (item['type'] == 'header') {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Text(
                            item['text'] as String,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: c.textPrimary, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        );
                      }
                      if (item['type'] == 'spacer') {
                        return const SizedBox(height: 150);
                      }
                      return StaggeredFadeIn(
                        index: index,
                        child: _buildPartCard(item['season'] as int, item['part'] as int),
                      );
                    },
                    childCount: items.length,
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              transitionBuilder: (child, anim) => SlideTransition(
                position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero).animate(anim),
                child: child,
              ),
              child: _current == null
                  ? const SizedBox.shrink(key: ValueKey('no-player'))
                  : KeyedSubtree(key: const ValueKey('player'), child: _buildPlayerBar()),
            ),
          ),
          // پرده‌ی تیره پشت پنل کناری
          if (_menuOpen)
            Positioned.fill(
              child: GestureDetector(
                onTap: () => setState(() => _menuOpen = false),
                child: Container(color: Colors.black.withOpacity(0.4)),
              ),
            ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            top: 0,
            bottom: 0,
            right: _menuOpen ? 0 : -(panelWidth + 24),
            width: panelWidth,
            child: _buildSidePanel(),
          ),
        ],
          );
        },
      ),
    );
  }

  Widget _buildSidePanel() {
    return Container(
      color: const Color(0xFF090C10),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 10),
            Row(
              children: [
                _tabButton('متن قسمت‌ها', 0),
                _tabButton('جلسات پرسش و پاسخ', 1),
                _tabButton('منابع', 2),
              ],
            ),
            Expanded(
              child: _menuTab == 0
                  ? _buildTranscriptList()
                  : _menuTab == 1
                      ? _buildQnaList()
                      : _buildSourcesList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabButton(String label, int index) {
    final selected = _menuTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _menuTab = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 2),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: selected ? c.accent : Colors.transparent, width: 2)),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: selected ? c.accent : Colors.white54,
              fontWeight: FontWeight.bold,
              fontSize: 10.5,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTranscriptList() {
    final items = <Map<String, int>>[];
    for (var i = 1; i <= 16; i++) {
      items.add({'season': 1, 'part': i});
    }
    items.add({'season': 2, 'part': 1});
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final season = items[i]['season']!;
        final part = items[i]['part']!;
        final label = season == 1 ? 'فصل یک — قسمت ${_toFarsiDigits(part)}' : 'فصل دوم — قسمت ${_toFarsiDigits(part)}';
        return GestureDetector(
          onTap: () => _openTranscript(season, part),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white12),
            ),
            child: Row(
              children: [
                Icon(Icons.picture_as_pdf_outlined, color: c.accent, size: 15),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 11.5)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildQnaList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      itemCount: kQnaItems.length,
      itemBuilder: (context, i) {
        final item = kQnaItems[i];
        final part = item.part;
        final isThis = _current == PlayingTrack(3, part);
        final playingHere = isThis && _isPlaying;
        final downloading = _qnaProgress.containsKey(part);
        final downloaded = _qnaDownloaded.contains(part);
        final key = _posKey(3, part);
        final isDone = _completedTracks.contains(key);
        final savedSec = _savedPositionSec[key];
        String? statusText;
        if (isDone) {
          statusText = '✓ شنیده شد';
        } else if (savedSec != null && savedSec >= 10) {
          statusText = '▶ ادامه از ${_fmt(Duration(seconds: savedSec))}';
        }
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: isThis ? c.accent.withOpacity(0.12) : Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: isThis ? c.accent : Colors.white12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'قسمت ${_toFarsiDigits(part)}',
                      style: TextStyle(
                        color: isThis ? c.accent : Colors.white,
                        fontSize: 12.5,
                        fontWeight: isThis ? FontWeight.bold : FontWeight.normal,
                      ),
                    ),
                    if (statusText != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(
                          statusText,
                          style: TextStyle(color: isDone ? c.accentDim : c.accent.withOpacity(0.85), fontSize: 9.5),
                        ),
                      ),
                  ],
                ),
              ),
              if (downloading)
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    value: _qnaProgress[part] == 0 ? null : _qnaProgress[part],
                    strokeWidth: 2.4,
                    color: c.accent,
                  ),
                )
              else if (downloaded) ...[
                GestureDetector(
                  onTap: () => _deleteQna(part),
                  child: const Icon(Icons.delete_outline, color: Colors.white38, size: 17),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () => _playQna(part),
                  child: playingHere
                      ? FadeTransition(
                          opacity: Tween<double>(begin: 0.4, end: 1.0).animate(_pulseCtrl),
                          child: Icon(Icons.pause_circle_filled, color: c.accent, size: 24),
                        )
                      : Icon(Icons.play_circle_fill, color: c.accent, size: 24),
                ),
              ] else
                GestureDetector(
                  onTap: () => _downloadQna(part),
                  child: Icon(Icons.download_rounded, color: c.accent, size: 22),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSourcesList() {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      children: [
        Text(
          'این منابع برای دسترسی به متن‌ها، صوت‌ها و اطلاعات تکمیلی مربوط به مستند «شنود» استفاده شده‌اند.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white54, fontSize: 11, height: 1.8),
        ),
        const SizedBox(height: 16),
        for (final s in kSourceItems)
          GestureDetector(
            onTap: () => _openUrl(s.url),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.link, color: c.accent, size: 14),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          s.title,
                          style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(s.subtitle, style: TextStyle(color: c.accent, fontSize: 11)),
                ],
              ),
            ),
          ),
      ],
    );
  }


  Widget _buildPlayerBar() {
    final title = _current!.season == 1
        ? 'فصل یک — قسمت ${_toFarsiDigits(_current!.part)}'
        : _current!.season == 2
            ? 'فصل دوم — قسمت ${_toFarsiDigits(_current!.part)}'
            : 'جلسات پرسش و پاسخ — قسمت ${_toFarsiDigits(_current!.part)}';
    final maxSeconds = _duration.inSeconds == 0 ? 1.0 : _duration.inSeconds.toDouble();
    final curSeconds = _position.inSeconds.toDouble().clamp(0.0, maxSeconds);
    return Material(
      color: c.cardBg,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      clipBehavior: Clip.antiAlias,
      elevation: 10,
      shadowColor: Colors.black.withOpacity(0.3),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(color: c.cardBorder, borderRadius: BorderRadius.circular(4)),
              ),
              Text(title, style: TextStyle(color: c.accent, fontWeight: FontWeight.bold, fontSize: 13.5)),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 3,
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                  overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                ),
                child: Slider(
                  value: curSeconds,
                  max: maxSeconds,
                  activeColor: c.accent,
                  inactiveColor: c.cardBorder,
                  onChanged: (v) => _player.seek(Duration(seconds: v.toInt())),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_fmt(_position), style: TextStyle(color: c.textSecondary, fontSize: 11.5)),
                    Text(_fmt(_duration), style: TextStyle(color: c.textSecondary, fontSize: 11.5)),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: () => _seekBy(-10), icon: Icon(Icons.replay_10, color: c.textSecondary, size: 25)),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => _playTrack(_current!.season, _current!.part),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: c.accent,
                        boxShadow: [BoxShadow(color: c.accent.withOpacity(0.4), blurRadius: 14)],
                      ),
                      child: Icon(_isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 30),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton(onPressed: () => _seekBy(10), icon: Icon(Icons.forward_10, color: c.textSecondary, size: 25)),
                  const SizedBox(width: 6),
                  IconButton(onPressed: _stopTrack, icon: Icon(Icons.stop_circle_outlined, color: c.textSecondary, size: 25)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
